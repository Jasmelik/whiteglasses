
let threeCamera;

const init_threeScene = function(spec) {
  const threeScene = THREE.JeelizHelper.init(spec, detect_callback);

  const ambientLight = new THREE.AmbientLight(0xffffff, 0.8);
  threeScene.scene.add(ambientLight);

  const dirLight = new THREE.DirectionalLight(0xffffff, 0.4);
  dirLight.position.set(100, 100, 100);
  threeScene.scene.add(dirLight);

  const loader = new THREE.GLTFLoader();
  loader.load('models/glasses.glb', function(gltf) {
    const glasses = gltf.scene;
    glasses.scale.set(1.2, 1.2, 1.2);
    glasses.position.set(0, 0.1, 0.3);
    THREE.JeelizHelper.get_faceObject().add(glasses);
  });

  return true;
};

const detect_callback = function(faceIndex, isDetected) {
  console.log('DETECTION', faceIndex, isDetected ? 'YES' : 'NO');
};

JEELIZFACEFILTER.init({
  canvasId: null,
  NNCpath: 'https://cdn.jsdelivr.net/npm/jeelizfacefilter/dist/', 
  callbackReady: function(errCode, spec) {
    if (errCode) {
      console.log('AN ERROR HAPPENED. ERROR CODE =', errCode);
      return;
    }
    console.log('INFO: JEELIZFACEFILTER IS READY');
    init_threeScene(spec);
  },
  callbackTrack: function(detectState) {
    THREE.JeelizHelper.render(detectState, threeCamera);
  }
});
